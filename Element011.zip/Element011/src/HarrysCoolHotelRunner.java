//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: Code that imports the javax.swing.JFrame package     *//
//* which will then allow the HarrysCoolHotel GUI to allow users      *//
//* to login either as a Manager or a Client 		    			  *// 
//* Date: 29/04/2020                                                  *//
//*                                                                   *//
//*********************************************************************//
// import the javax.swing.JFrame package  
import javax.swing.JFrame;
// The name of the class is HarrysCoolHotelRunner 
// Which will allow the class HarrysCoolHotel to display the GUI
public class HarrysCoolHotelRunner 
{	
	// Declare instance fields 
	private static HarrysCoolHotel  harrysApp;
	// Main method to make the GUI visible 
	public static void main(String[] args)
	{
		harrysApp = new HarrysCoolHotel();
		harrysApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		harrysApp.setSize(600, 400);
		harrysApp.setVisible(true);
	} // End of main method 
} // End of the class 