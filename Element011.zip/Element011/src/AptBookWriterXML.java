//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: A child class which extends the class AWriterforXML  *//
//* this will allow the Apartment XML file to be written              *//
//* Date: 17/05/2020                                                  *//
//*                                                                   *// 
//*********************************************************************//
// Import the necessary packages 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import javax.swing.JOptionPane;
//------------------------------------------------------------------------
// The name of the class is AptBookWriterXML which extends the class AWriterforXML
public class AptBookWriterXML extends AWriterforXML 
{
	// Declare instance fields for the class 
	private Element theBaseElement;
	private Element AptBook;
	private Element apartmentID;
	private Attr theAttribute;
	private Element initialName;
	private Element surName;
	private Element numOfGuests;
	private Element dateBegin;
	private Element dateFinish;
	private Element toilet;
	private Element sofa;
	private Element food;
	private TransformerFactory factorTrans;
	private Transformer trans;
	private DOMSource power;
	private StreamResult theResults;
	private StreamResult theResultsConsole;
	// instance field for the users BID
	private int BID = 001;
	//------------------------------------------------------------------------
	// A constructor named AptBookWriterXML which will instantiate the declared
	// instance fields 
	public void AptBookWriterXML(Document chronicle, String chronicleCreator, String initialName, String surName, 
			String numOfGuests, String dateBegin, String dateFinish, String food)
	{
		// A try method to gather all the elements and create the necessary nodes 
		try 
		{
			// The instance field theBaseElement is initialised
			theBaseElement = chronicle.createElement("Booking Maker");
			chronicle.appendChild(theBaseElement);
			// The aptBook instance field is initialised
			AptBook = chronicle.createElement("Appartment Booking");
			chronicle.appendChild(AptBook);
			// For the BID number, theAttribute instance field can be treated as the ID for the client
			theAttribute = chronicle.createAttribute("Identification");
			// The BID instance field can then be used to generate newer BID numbers for different users 
			BID = BID + 1; // this is done through incrementation 
			theAttribute.setValue(Integer.toString(BID));
			JOptionPane.showMessageDialog(null, "Thank you for the booking. here is your Booking Identification Number:  " + BID);
			AptBook.setAttributeNode(theAttribute);
			// The instance field for the apartment name is initialised 
			apartmentID  = chronicle.createElement("Name of Apartment");
			apartmentID.appendChild(chronicle.createTextNode(aptName));
			AptBook.appendChild(apartmentID); 
			// initial Name is 
			initialName = chronicle.createElement("First Name");
			initialName.appendChild(chronicle.createTextNode(initialName));
			// The surName element for the XML writer
			surName = chronicle.createElement("Surname");
			surName.appendChild(chronicle.createTextNode(surName));
			// The numOfGuests element for the XML writer
			numOfGuests = chronicle.createElement("numOfGuests");
			numOfGuests.appendChild(chronicle.createTextNode(numOfGuests));
			// The dateBegin element for the XML writer
			dateBegin = chronicle.createElement("dateBegin");
			dateBegin.appendChild(chronicle.createTextNode(dateBegin));
			// The dateFinish element for the XML writer
			dateFinish = chronicle.createElement("dateFinish");
			dateFinish.appendChild(chronicle.createTextNode(dateFinish));
			// The dateFinish element for the XML writer
			food = chronicle.createElement("Catering");
			food.appendChild(chronicle.createTextNode(food));
			//------------------------------------------------------------------------
			// the TransformerFactory will write the content into the ApartmentBook XML file
			factorTrans = TransformerFactory.newInstance();
			trans = TransformerFactory.newTransformer();
			
			power = new DOMSource(chronicle);
			
			theResults = new StreamResult(new File(file2BeWritten));
			trans.transform(power, theResults);
			//------------------------------------------------------------------------
		// Testing is done by outputting the console
		theResultsConsole = new StreamResult(System.out);
		trans.transform(power, theResultsConsole);
		//------------------------------------------------------------------------
		} // End of try 
		// A catch statement is used for error handling 
		catch (Exception a)
		{
			a.printStackTrace();
		} // End of catch 
	} // End of method 
} // End of class 
