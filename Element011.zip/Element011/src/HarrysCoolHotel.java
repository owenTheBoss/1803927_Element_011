//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: An Graphics User Interface application that will     *//
//* display login details for either A the Manager or B the client    *//
//* by containing a prompt for the user name and password 		      *// 
//* Date: 17/05/2020                                                  *//
//*                                                                   *// 
//*********************************************************************//
// Import the necessary packages 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
// The name of the class is HarrysCoolHotel which will be extended 
public class HarrysCoolHotel extends JFrame implements ActionListener  // The JFrame will allow the ActionListener to be implemented 
{ 
	// Declare instance fields 
	private final FlowLayout guiFlowNo1;
	private final FlowLayout guiFlowNo2;
	private final FlowLayout guiFlowNo3;
	private final BorderLayout mainBorder1;
	private final BorderLayout mainBorder2;
	private final BorderLayout mainBorder3;
	//---------------------------------------------------------------------------------------------------------------------
	// Declare the instance fields that will be used for the client booking 
    private BorderLayout cliBookBorderNo1; // For the first panel in the client Booking Maker section
	private BorderLayout cliBookBorderNo2; // For the apartment section
	private BorderLayout cliBookBorderNo3; // For the Booking Maker's JLabel's and JTextFields
	private BorderLayout cliBookBorderNo4; 
	private BorderLayout cliBookBorderNo5;
	private FlowLayout cliBookFlowNo1; 
	private FlowLayout cliBookFlowNo2;
	//---------------------------------------------------------------------------------------------------------------------
	// Declare JPanels 
	private final JPanel panelNo1;
	private final JPanel panelNo2; 
	private final JPanel panelNo3;
	private final JPanel panelNo4; 
	private final JPanel panelNo5;
	//---------------------------------------------------------------------------------------------------------------------
	// The Booking JPanels which will be used for the Booking Maker option on the Client side 
	private JPanel bookPanelNo1;
	private JPanel bookPanelNo2;
	private JPanel bookPanelNo3;
	private JPanel bookPanelNo4;
	private JPanel bookPanelNo5;
	//---------------------------------------------------------------------------------------------------------------------
	// The JLabels that will be used for the Booking Maker section
	private JLabel apartmentName; // JLabel for the name of the Apartment
	private JLabel initialName; // JLabel for Client's first name
	private JLabel surName; // JLabel for Client's surname
	private JLabel numOfGuests; // JLabel for the maximum number of guests
	private JLabel roomCatering; // JLabel for the option of catering
	private JLabel dateBegin; // JLabel for the start date when booking an apartment
	private JLabel dateFinish; // JLabel for the end date of the booking 
	// JText fields for the client Booking Maker to go with the corresponding JLabels
    private JTextField apartmentText; // JTextField for the apartment name 
    private JTextField initalText; // JTextField for the client's first name 
    private JTextField surText; // JTextField for the clients surname 
    private JTextField guestText; // JTextField for the number of guests 
    private JTextField caterText; // JTextField for if the client wants catering 
    private JTextField firstdateText; // JTextField for the booking start date 
    private JTextField lastDateText; // JTextField for the end date of the booking 
    //---------------------------------------------------------------------------------------------------------------------
    // Declare the login detail JLabels 
    private final JLabel logPrompt; // JLabel for the login character
	private final JLabel labelUsername; // JLabel for the User name 
	private final JLabel labelPassword; // JLabel for the password 
	//---------------------------------------------------------------------------------------------------------------------
	// For the manager and client side menus the JLabel and JTextField are declared 
	private JLabel cliMenChoiceLabel;
	private JLabel manMenChoiceLabel;
	private JTextField cliMenDecisionText;
	private JTextField manMenDecisionText;
	private String cliMenOption = "";
    private String manMenOption = "";
    //---------------------------------------------------------------------------------------------------------------------
    // A font is declared for the Manager side 
    private Font managerSideFont;
    // Also same applies for the client side as well
    private Font clientSideFont;
    private final JTextField loginCharWriter; // JTextField to allow the login character to be inserted when logging into 
	// the Management system (A for manager B for client) 
    private final JTextField loginUserWriter; // JTextField to allow the user to insert the user name 
    private final JTextField loginPassWriter; // JTextField to allow the password to be inserted
    private String manChoice = "";
    private String cliChoice = "";
    //---------------------------------------------------------------------------------------------------------------------
    private String userName = ""; // userName is blank because there are two user names 1 for Manger, 1 for Client  
  	String passWord = ""; // passWord is blank because there are two passwords 1 for Manger, 1 for Client  
  	String accessDecisionKey = ""; // accessDecisionKey will be either A for Manager or B for Client
  	//---------------------------------------------------------------------------------------------------------------------
  	// A boolean type instance field called user access is set to false to determine if the user 
    // has inserted the correct credentials, if so then it will be changed to true
    private boolean userAccess = false;
    private int attemptNo = 0; // Integer instance field to represent the numer of login attempts 
    private boolean ManSideMenu = false; // Once user accesses the Manager Side menu the boolean will change to true
    private boolean clientSideMenu = false; // Once user accesses the Client Side menu the boolean will change to true
    private boolean bookSetWrite = false; // Boolean for to allow the details to be displayed
  //---------------------------------------------------------------------------------------------------------------------
    // A 2Dimensional array is used for the instance field userCredentials, containing both a user name and 
    // password 
    private String [] [] userCredentialsMan = {{"Manager", "!Mth3M@n@g3r"}};
    private String [] [] userCredentialsCli = {{"Client", "!Mth3cl!3nt"}};
    // String instance fields are used to allow either the username and passwords to be inserted 
    private String manUserID = "";
	private String manPassID = "";
    private String cliUserID = "";
	private String cliPassID = "";
	//---------------------------------------------------------------------------------------------------------------------
    // Declare the JButton for booking 
    private JButton bookButton; 
    // JFrame for the Client Side Booking Maker option 
    private JFrame bookTheFrame;
	//---------------------------------------------------------------------------------------------------------------------
    // The XML reader for the apartments are declared to allow it to be displayed in a panel
    private ReadAptsXML theReaderforApts;
    private String[][] aptsInfo = new String[10][9];
    private String theColumns[]= {"aptID", "aptName", "totalCost", "dateBegin", "dateFinish", "numOfGuests", "sleepRooms", "toilets", "Sofa"};
    //---------------------------------------------------------------------------------------------------------------------
    // Declare panels to allow the XML file to be displayed 
    private JPanel xmlShow;
    private JFrame xmlShower;
    private JScrollPane scrollThrougher;
    //---------------------------------------------------------------------------------------------------------------------
    // The document and XML writer are then called
    private Document chronicleWriter;
    private AptBookWriterXML theAptWriter;
    //---------------------------------------------------------------------------------------------------------------------
    // Strings for the Client Side booking maker 
    private String bookAptName = "";
    private String bookInitialName = "";
    private String bookSurName = "";
    private String bookGuestNumber = "";
    private String bookDateBegin = "";
    private String bookDateEnd = "";
    private String bookFoodService = "";
    //---------------------------------------------------------------------------------------------------------------------
    // Instance fields for the document and construction are declared 
    private Document chronicle; 
	private DocumentBuilderFactory docFactory; 
	private DocumentBuilder docConstruction;
	private File fileInsertion;
    //---------------------------------------------------------------------------------------------------------------------
	// A constructor is called named HarrysCoolHotel without any arguments
	// The constructor is used to instantiate the declared instance fields 
	// And generate the GUI
	public HarrysCoolHotel()
	{
		super("Harry's Hotel California");
		// The guiFlow instance fields are instantiated for new FlowLayouts
		guiFlowNo1 = new FlowLayout();
		guiFlowNo2 = new FlowLayout();
		guiFlowNo3 = new FlowLayout();
		mainBorder1 = new BorderLayout();
		mainBorder1.setHgap(10);
		mainBorder1.setVgap(10);
		mainBorder2 = new BorderLayout();
		mainBorder3 = new BorderLayout();
		//---------------------------------------------------------------------------------------------------------------------
		// After initialising the layouts for the GUIs the JLabels are given initialisation
		// As well as the JText fields that correspond to them 
		// furthermore Action listener is implemented to ensure functionality
		logPrompt = new JLabel("Please insert your Username and Password ( Options are A: Manager, B: Client");
		loginCharWriter = new JTextField(50);
		loginCharWriter.addActionListener(this);
		//---------------------------------------------------------------------------------------------------------------------
		// A setter method is used as a mutator for the layout in the GUI
		// As well as providing the initialisation to the other JLabels and JTextFields
		setLayout(guiFlowNo1);
		panelNo1 = new JPanel();
		panelNo2 = new JPanel();
		panelNo3 = new JPanel();
		panelNo4 = new JPanel();
		//---------------------------------------------------------------------------------------------------------------------
		panelNo1.setLayout(mainBorder1);    
  		panelNo1.setVisible(true);
  		this.add(panelNo1);    
  		panelNo2.setLayout(mainBorder2);    
  		panelNo2.setVisible(true);
  		panelNo3.setLayout(mainBorder3);
  		panelNo3.setVisible(true);
  		panelNo1.add(panelNo2, BorderLayout.EAST);
  		this.add(panelNo1);   
  		panelNo1.add(panelNo3, BorderLayout.WEST);
  		this.add(panelNo1);
  		
  		panelNo4.setLayout(guiFlowNo3);
  		panelNo4.setVisible(true);
  		panelNo1.add(panelNo4, BorderLayout.SOUTH);                  
  		this.add(panelNo1); 
  	    //---------------------------------------------------------------------------------------------------------------------
  		// The login credential JLabels are set to visible 
		logPrompt.setVisible(true);
		panelNo3.add(logPrompt, BorderLayout.NORTH);
		panelNo2.setVisible(true);
		panelNo1.add(panelNo2, BorderLayout.WEST);
		this.add(panelNo1);
		//---------------------------------------------------------------------------------------------------------------------
		// The Text Field loginCharWriter is initialised with its
		// sized being set as well being configure to be visible to allow the 
		// user to see the text field to write within it 
		loginCharWriter.setSize(100, 100);
		loginCharWriter.setVisible(true);
		panelNo2.add(loginCharWriter, BorderLayout.NORTH);
		panelNo2.setVisible(true);
		panelNo1.add(panelNo2, BorderLayout.EAST);
		this.add(panelNo1);
		//---------------------------------------------------------------------------------------------------------------------
		// The username instance fields are initialised 
		labelUsername = new JLabel("Username");
		loginUserWriter = new JTextField(15);
		loginUserWriter.addActionListener(this);
		// The JLabel label labelUsername is set to visible 
		labelUsername.setVisible(true);
		panelNo3.add(labelUsername, BorderLayout.CENTER);
		panelNo3.setVisible(true);
		panelNo1.add(panelNo3, BorderLayout.WEST);
        this.add(panelNo1);
      //---------------------------------------------------------------------------------------------------------------------
      // The JTextFIeld loginUserWriter is set to visible 
        loginUserWriter.setSize(100, 100);
        loginUserWriter.setVisible(true);
        panelNo3.add(loginUserWriter, BorderLayout.CENTER);
        panelNo3.setVisible(true);
        panelNo1.add(panelNo3, BorderLayout.EAST);
        this.add(panelNo1);  
      //---------------------------------------------------------------------------------------------------------------------
      // The password label and text fields are initialised with action listener implemented 
        labelPassword = new JLabel("Password");
        loginPassWriter = new JTextField(15);
        loginPassWriter.addActionListener(this);
                  
        labelPassword.setVisible(true);
        panelNo3.add(labelPassword, BorderLayout.SOUTH);
        panelNo3.setVisible(true);
        panelNo1.add(panelNo3, BorderLayout.WEST);
        this.add(panelNo1);
                  
        loginPassWriter.setSize(100, 100);
        loginPassWriter.setVisible(true);
        panelNo3.add(loginPassWriter, BorderLayout.SOUTH);
        panelNo3.setVisible(true);
        panelNo1.add(panelNo3, BorderLayout.EAST);
        this.add(panelNo1); 
      //---------------------------------------------------------------------------------------------------------------------
     // The labels and text fields for the booking are given initialisation 
        apartmentName = new JLabel("Apartment Name");
        apartmentText = new JTextField(15);
        apartmentText.addActionListener(this);
  		
        initialName = new JLabel("First Name of Client");
        initalText = new JTextField(15);
        initalText.addActionListener(this);
   		
        surName = new JLabel("Surname of Client");
        surText = new JTextField(15);
        surText.addActionListener(this);
   		
        numOfGuests  = new JLabel("Number of Guests");
        guestText = new JTextField(15);
        guestText.addActionListener(this);
   		
        dateBegin = new JLabel("Strting Date");
        firstdateText = new JTextField(15);
        firstdateText.addActionListener(this);
   		
        dateFinish = new JLabel("Ending Date");
        lastDateText = new JTextField(15);
        lastDateText .addActionListener(this);
   		
        roomCatering = new JLabel("Catering?(Y/N)");
        caterText = new JTextField(15);
        caterText.addActionListener(this); 
      //---------------------------------------------------------------------------------------------------------------------
      // Initialise the xmlShower and xmlShow instance fields 
  		xmlShow = new JPanel();
  		xmlShower = new JFrame();	
	} // End of constructor 
	//---------------------------------------------------------------------------------------------------------------------
	// A public method to support the User logging into the GUI
	public void conductAction(ActionEvent event)
	{
		// The Instance field accessDecisionKey is assigned to the loginCharWriter
		// Text field to allow the instance field to be inserted into the JTextField
		accessDecisionKey = loginCharWriter.getText();
		// A statement is written to allow the program to be debugged
		System.out.println("The key is eiher A or B");
		//---------------------------------------------------------------------------------------------------------------------
		// The userName instance field is assigned to the loginUserWriter JTextField
		userName = loginUserWriter.getText();
		// Similar to the accessDecisionKey, a debug message is also used
		System.out.println("Usernames to Access");
		//---------------------------------------------------------------------------------------------------------------------
		// The passWord instance field is assigned to the loginPassWriter JTextField
		passWord = loginPassWriter.getText();
		// Similar to both the accessDecisionKey and userName, a debug message is also used
		System.out.println("Passwords to Access");
		//---------------------------------------------------------------------------------------------------------------------
		// Read the client side options 
		cliMenOption = cliMenDecisionText.getText();
		// Debug statement is ERDRICK
		System.out.println("The debug message is ERDRICK" + cliMenOption);
		//---------------------------------------------------------------------------------------------------------------------
		// A while loop used for the number of login attempts 
		while (userAccess == false)
		{
			for(int a = 0; a<2; a++)
	    	{
				// Manager Credentials 
				manUserID = userCredentialsMan[a][0];
				manPassID = userCredentialsMan[a][1];
				// Client credentials 
				cliUserID = userCredentialsCli[a][0];
				cliPassID = userCredentialsCli[a][1];
				
				// Debugging  for the instance field cliUserID
				System.out.println("An Error Draws Near, Command?  " + cliUserID);
				// An if statement to determine if the the boolean logAccess is set to false 
				// then it will run a sub-if statement to determine if the characters within the array 
				// match up to what is inserted within the JTextFields
				if ((new String(userName).equals(cliUserID)) & new String(passWord).equals(cliPassID) & new String(accessDecisionKey).equals("B"))	
				{
					// A debug statement is run 
					System.out.println("This guy's the Client");
					// Once the login credentials match the array, a JPane will be displayed with a message to 
					// that says "Access Granted, Welcome Manager" to show the user is granted access
					JOptionPane.showMessageDialog(this,  "Access Granted, Welcome Client");
					// The userAccess instance field is then set to true
					userAccess = true; 
					clientSideMenu = true; 
					// Once the client user has Access then the Menu options on the CLient side will be displayed
					StringBuilder cliBuff = new StringBuilder();
					cliBuff.append("<html><table>");
					cliBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "The Client Side"));                     
					cliBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "A. Booking Maker"));
					cliBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "B. Booking Manager"));
					cliBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "X. Exit"));
					cliBuff.append("</table></html>");
			        // The labels are given a font of Arial and made to be bold with a size of 23
			        clientSideFont = new Font("Arial", Font.BOLD, 23);
					//---------------------------------------------------------------------------------------------------------------------
			        // The cliMenChoiceLabel instance field is initialised and configured 
			        cliMenChoiceLabel = new JLabel(cliBuff.toString());    
			        cliMenChoiceLabel.setFont(clientSideFont);
			        //clientMenuOptionsLabel.setVisible(true);
			        panelNo2.add(cliMenChoiceLabel, BorderLayout.NORTH);
			        panelNo2.setVisible(true);
			        panelNo1.add(panelNo2, BorderLayout.SOUTH);
			        panelNo1.revalidate();
			        panelNo1.repaint();
			  		this.add(panelNo1);
					//---------------------------------------------------------------------------------------------------------------------
			  		// The cliMenDecisionText instance field is initialised and configured 
			  		cliMenDecisionText = new JTextField(50);
			  		cliMenDecisionText.addActionListener(this);
			    	cliMenDecisionText.setVisible(true);
			    	panelNo2.add(cliMenDecisionText, BorderLayout.SOUTH);
			    	panelNo2.setVisible(true);
			    	panelNo1.add(panelNo2, BorderLayout.SOUTH);
			    	panelNo1.revalidate();
			    	panelNo1.repaint();
			        this.add(panelNo1);
			        // The clientSideMenu is set to true 
			        clientSideMenu = true;
				} // End of if statement 
				// An else if statement for if the Manager credentials are inserted 
				else if ((new String(userName).equals(manUserID)) & new String(passWord).equals(manPassID) & new String(accessDecisionKey).equals("A"))
				{
					// Debug Statement 
					System.out.println("A wild Manager Appaers!");
					JOptionPane.showMessageDialog(null,"Welcome Manager");
					// The userAccess instance field is then set to true
					userAccess = true; 
					// The attempt number is also set to 3 
					attemptNo = 3; 
					// The Manager side options are displayed 
					StringBuilder manBuff = new StringBuilder();
					manBuff.append("<html><table>");
					manBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "Manager Side"));                     
					manBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "A. Booking Viewer"));
					manBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "B. Booking Manager"));
					manBuff.append(String.format("<tr><td align='left'>%s</td>" + "</tr>", "X. Exit"));
					manBuff.append("</table></html>");
	    			// The manager font is configured  
	    			managerSideFont = new Font("Arial", Font.BOLD, 23);
	    			// The instance field manMenChoice JLabel is configured 
	    			manMenChoiceLabel = new JLabel(manBuff.toString());    
	    			manMenChoiceLabel.setFont(managerSideFont);
			        manMenChoiceLabel.setVisible(true);
	    			panelNo2.add(manMenChoiceLabel, BorderLayout.NORTH);
	    			panelNo2.setVisible(true);
	    			panelNo1.add(panelNo2, BorderLayout.SOUTH);
	    			panelNo1.revalidate();
	    			panelNo1.repaint();
			  		this.add(panelNo1);
			  		// The manMenDecisionText JText field is initialised and configured 
			  		manMenDecisionText = new JTextField(50);
			  		manMenDecisionText.addActionListener(this);
			    	manMenDecisionText.setVisible(true);
			    	panelNo2.add(manMenDecisionText, BorderLayout.SOUTH);
			    	panelNo2.setVisible(true);
			    	panelNo1.add(panelNo2, BorderLayout.SOUTH);
			    	panelNo1.revalidate();
			    	panelNo1.repaint();
			        this.add(panelNo1);
				} // End of Else if statement 
				// An else statement for if the user fails to enter the correct login details 
				else 
				{
					// An if statement for if the wrong details are entered then the attemptNo instance field will increment by 1
					if ((attemptNo==0) & (userAccess==false))
					{
						attemptNo = attemptNo + 1;
						JOptionPane.showMessageDialog(this, "Its a Hacker!");
					} // End of if statement 
				} // End of else statement 
	    	} // End of for loop 
		} // End of while loop 
		// An if statement for while the client menu is displayed it will run the specific requirments 
		if (clientSideMenu==true)
		{
			if (new String(cliMenDecisionText.getText()).equals("A"))
			{
				// Debugging statement
				System.out.println("Fun Time!");
	      		
				theReaderforApts = new ReadAptsXML();
				chronicleWriter  = new theAptWriter(); 
	      		
				theReaderforApts = theReaderforApts.ReaderforApts();
	      	
	      		// A new frame is created for the booking 
				bookTheFrame = new JFrame("Booking Maker");	
				bookTheFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				bookTheFrame.setSize(1200, 500);
				bookTheFrame.setVisible(true);
				
				// The options are displayed while initialising the corresponding JLAbels 
				cliBookFlowNo1 = new FlowLayout(); // The main Booking Maker JPane
				cliBookBorderNo1 = new BorderLayout(); // Main Booking Panel 
				cliBookBorderNo2 = new BorderLayout(); // Border Layout to view the apartments 
				cliBookBorderNo3 = new BorderLayout(); // Border Layout for the booking options 
				cliBookFlowNo2 = new FlowLayout(); // Flow layout for the entire booking options 
		  		cliBookBorderNo1.setHgap(10); 
		  		cliBookBorderNo1.setVgap(10);
		  		// The instance field is set to the main booking flow layout 
		  		bookTheFrame.setLayout(cliBookFlowNo1);        
                // Booking JPanels are initialised 
		  		bookPanelNo1 = new JPanel();
		  		bookPanelNo2 = new JPanel();
		  		bookPanelNo3 = new JPanel();
		  		bookPanelNo4 = new JPanel();
		  		bookPanelNo5 = new JPanel();
		  		
		  		bookPanelNo1.setLayout(cliBookBorderNo1);
		  		bookTheFrame.add(bookPanelNo1);
		  		
		  		bookPanelNo2.setLayout(cliBookBorderNo2);    
		  		bookPanelNo2.setVisible(true);
		  		bookPanelNo1.add(bookPanelNo2, BorderLayout.NORTH);    
		  		bookTheFrame.add(bookPanelNo1);
		  		
		  		bookPanelNo3.setLayout(cliBookFlowNo2);    
		  		cliBookFlowNo2.setAlignment(FlowLayout.CENTER);
		  		bookPanelNo2.setVisible(true);
		  		bookPanelNo1.add(bookPanelNo2, BorderLayout.SOUTH);
		  		bookTheFrame.add(bookPanelNo1);
		  		// the apartment XML reader is set to the table viewer 		  		
		  		ReadAptsXML.XMLtableViewer(aptsInfo, theColumns, bookPanelNo2, bookTheFrame);
		  		
		  		
		  		bookSetWrite = true;  		
		  		
		} // End of if statement
		//---------------------------------------------------------------------------------------------------------------------
	} // End of If statement 
	//---------------------------------------------------------------------------------------------------------------------
	// An if statement to display the apartment details 
		if (bookSetWrite == true)
		{
			// Label and text field for the Apartment Name
			apartmentName.setVisible(true);
			bookPanelNo3.add(apartmentName, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			apartmentText.setSize(15, 15);
			apartmentText.setVisible(true);
			bookPanelNo3.add(apartmentText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for the Client's first name
			initialName.setVisible(true);
			bookPanelNo3.add(initialName, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			initalText.setSize(20, 15);
			initalText.setVisible(true);
			bookPanelNo3.add(initalText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for the Client's surname
			surName.setVisible(true);
			bookPanelNo3.add(surName, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			surText.setSize(15, 15);
			surText.setVisible(true);
			bookPanelNo3.add(surText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for the number of guests
			numOfGuests.setVisible(true);
			bookPanelNo3.add(numOfGuests, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			guestText.setSize(15, 15);
			guestText.setVisible(true);
			bookPanelNo3.add(guestText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for the starting date
			dateBegin.setVisible(true);
			bookPanelNo3.add(dateBegin, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			firstdateText.setSize(15, 15);
			firstdateText.setVisible(true);
			bookPanelNo3.add(firstdateText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for the ending date
			dateFinish.setVisible(true);
			bookPanelNo3.add(dateFinish, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			lastDateText.setSize(20, 15);
			lastDateText.setVisible(true);
			bookPanelNo3.add(lastDateText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// Label and text field for if the user wants catering
			roomCatering.setVisible(true);
			bookPanelNo3.add(roomCatering, BorderLayout.NORTH);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH); 
			bookTheFrame.add(bookPanelNo1);	    			                  
	                  
			caterText.setSize(15, 15);
			caterText.setVisible(true);
			bookPanelNo3.add(caterText, BorderLayout.CENTER);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			//---------------------------------------------------------------------------------------------------------------------
			// The JButton is initialised 
			bookButton = new JButton("Make Booking");
			bookButton.addActionListener(this);
			bookButton.setActionCommand("Make Booking");
			bookButton.setVisible(true);
			bookPanelNo3.add(bookButton);
			bookPanelNo3.setVisible(true);
			bookPanelNo1.add(bookPanelNo3, BorderLayout.NORTH);
			bookTheFrame.add(bookPanelNo1);
			// An if statement for if the JButton is pressed 
			if ("Make Booking".equals(event.getActionCommand())) 
	  		{
				bookAptName = apartmentText.getText();
				bookInitialName = initalText.getText();
				bookSurName = surText.getText();
				bookGuestNumber = guestText.getText();
				bookDateBegin = firstdateText.getText();
				bookDateEnd = lastDateText.getText();
				bookFoodService = caterText.getText();
		  		
				chronicleWriter = chronicleWriter.connectionMade();
		  		
				theAptWriter.bookingWriter(chronicleWriter, "H:\\eclipse\\workspace\\GUI Layout\\HotelApts.xml", 
		  				bookAptName, bookInitialName, bookSurName, bookGuestNumber, bookDateBegin, bookDateEnd, bookFoodService);
		  		    				
	  		} // End of if statement 
		} // End of if statement 
} // End of class 
