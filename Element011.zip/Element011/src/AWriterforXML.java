//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: A parent class named AWriterforXML which will be     *//
//* used as the XML writer for the program which will be extended     *//
//* by the child classes AptBookWriterXML and BookConfirWriterXML. 	  *// 
//* Date: 12/05/2020                                                  *//
//*                                                                   *// 
//*********************************************************************//
// Import the necessary packages 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
//-------------------------------------------------------------------------
// the name of the class is AWriterforXML 
public class AWriterforXML 
{
	// Declare the class instance fields 
	private Document chronicle; 
	private DocumentBuilderFactory docFactory; 
	private DocumentBuilder docConstruction;
	//-------------------------------------------------------------------------
	// A public method with no arguments called connectionMade which uses a try and catch command 
	// to both initialise the instance fields but also provide debugging 
	public Document connectionMade()
	{
		try
		{
			// Instance fields are instantiated to provide the XML writer 
			// the needed layers 
			chronicle = docConstruction.newDocument();
			docFactory = DocumentBuilderFactory.newInstance();
			docConstruction = docFactory.newDocumentBuilder();
		} 
		catch (Exception a)
		{
			a.printStackTrace();
		} // End of try and catch method 
		// the instance field chronicle is returned
		return chronicle; 
	} // End of method 

} // End of class 
