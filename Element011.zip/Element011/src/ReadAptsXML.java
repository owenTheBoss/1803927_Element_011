//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: A child XML reader that extends the aReaderforXML    *//
//* this will be used for the apartment section in the Hotel         *//
//* Management System.												  *// 
//* Date: 18/05/2020                                                  *//
//*                                                                   *// 
//*********************************************************************//
// Import the necessary packages 
import javax.swing.*;
import java.awt.*;
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
//-------------------------------------------------------------------------------
// the name of the class is ReadAptsXML which will extend the aReaderforXML class
public class ReadAptsXML extends aReaderforXML
{
	// Declare instance fields
	private Document theChronicle;
	private String[][] information  = new String[10][9];	
	String theColumns[]= {"aptID", "aptName", "totalCost", "dateBegin", "dateFinish", "numOfGuests", "sleepRooms", "toilets", "Sofa"};
	// Integer instance fields are declared and initialised 
	// to be used as counters for the table's columns and rows 
	private int columnNo = 0; 
	private int rowNo = 0;
	// instance fields for the JTable containing all the apartment 
	// information are declared 
	private JTable tableOfApts;
	private JScrollPane panelScrolling;
	//-------------------------------------------------------------------------------
	// A method used to instantiate the instance fields and 
	// create the Apartment table
	public String[][] theAptReader()
	{
		tableOfApts = new JTable(information,theColumns);    
		tableOfApts.setBounds(30,40,200,300);
		panelScrolling = new JScrollPane(tableOfApts);
		// The directory is set to go to the HotelApts.xml file 
		theChronicle = connectionMade("H:\\\\eclipse\\\\workspace\\\\GUI Layout\\\\HotelApts.xml");
		System.out.println("Root element :" + theChronicle.getDocumentElement().getNodeName());
		NodeList listNodes = theChronicle.getElementsByTagName("HotelApts");
		System.out.println("-----------------");
		//-------------------------------------------------------------------------------
		// A for iteration which will also declare and initialise an instance field called
		// "number", while the number is less than the length of the node list then it will
		// print the elements along with the name of the node from the XML file
		for (int number  = 0; number  < listNodes.getLength(); number ++)
		{
			Node theNode = listNodes.item(number);
			System.out.println("\nElement Now :" + theNode.getNodeName());
			//-------------------------------------------------------------------------------
			// An if statement for each node within the apartment XML file 
			if (theNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) theNode;
				String apartmentID_Table = eElement.getAttribute("AptID");
				String apartmentName_Table  = eElement.getElementsByTagName("aptName").item(0).getTextContent();
				String cost_Table = eElement.getElementsByTagName("Cost").item(0).getTextContent();
				String dateBegin_Table  = eElement.getElementsByTagName("dateBegin").item(0).getTextContent();
				String dateFinish_Table  = eElement.getElementsByTagName("dateFinish").item(0).getTextContent();
				String numOfGuests_Table  = eElement.getElementsByTagName("numOfGuests").item(0).getTextContent();
				String sleepRooms_Table  = eElement.getElementsByTagName("sleepRoom").item(0).getTextContent();
				String toilets_Table  = eElement.getElementsByTagName("toilets").item(0).getTextContent();
				String sofa_Table  = eElement.getElementsByTagName("Sofa").item(0).getTextContent();
				// The apartmentID data is added to the table 
				information[rowNo][columnNo] = apartmentID_Table;
				columnNo = columnNo + 1;
				// The apartmentName is added to the table 
				information[rowNo][columnNo] = apartmentName_Table;
				columnNo = columnNo + 1;
				// Cost of the apartment is added to the table 
				information[rowNo][columnNo] = cost_Table;
				columnNo = columnNo + 1;
				// the starting date of the booking is added into the table 
				information[rowNo][columnNo]  = dateBegin_Table;
				columnNo = columnNo + 1;
				// The finishing date of the booking is added into the table 
				information[rowNo][columnNo] = dateFinish_Table;
				columnNo = columnNo + 1;
				// The amount of guests are added into the table 
				information[rowNo][columnNo]  = numOfGuests_Table;
				columnNo = columnNo + 1;
				// The number of bedrooms are added into the table 
				information[rowNo][columnNo] = sleepRooms_Table;
				columnNo = columnNo + 1;
				// The number of bathrooms are added into the table 
				information[rowNo][columnNo] = toilets_Table;
				columnNo = columnNo + 1;
				// the determination of whether or not a living room is in the appartment is added into the table 
				information[rowNo][columnNo] = sofa_Table;
				//Statements are created to provide debugging for
				// When the if statement is running 
				System.out.println("Apt Identification " +  apartmentID_Table);
				System.out.println("Total Cost  " + cost_Table);				
			    System.out.println("Begining Date " + dateBegin_Table);
				System.out.println("Finishing Date " + dateFinish_Table);
				System.out.println("Num of Guests " + numOfGuests_Table);
				System.out.println("Beds " + sleepRooms_Table);
				System.out.println("Bathroom Amount " + toilets_Table);
				System.out.println("is there a livingroom " + sofa_Table);
			} // End of if statement 
			// instance field rowNo is incremented by 1 similar to the columnNo instance field
			rowNo = rowNo + 1;
			columnNo = 0;
		} // end of for loop 
		// The information instance field is returned
			return information;
	} // end of method 
	// A method used to create the table for the apartment reader so that the information from
	// the Apartments XML file can be displayed 
	public void XMLtableViewer(String[][] theTable, String theColumn[], JPanel panelShow, JFrame showTheFrame)
	{
		// Table dimensions 
		tableOfApts = new JTable(theTable,theColumn);
		tableOfApts.setBounds(30,40,1200,200);
		panelScrolling.add(panelScrolling);
		
		panelShow.add(panelShow);
		showTheFrame.setVisible(true);
	} // End of method 
} // End of class 
