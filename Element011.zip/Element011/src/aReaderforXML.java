//*********************************************************************//
//* Name: 1803927                                                     *//
//* Task: Element 011                                                 *//
//* Description: An XML reader class that will be used to the XML     *//
//* files which will be used as the parent class for the child classes*//
//* ReadBooksXML and ReadAptsXML which are also XML reader classes    *// 
//* Date: 13/05/2020                                                  *//
//*                                                                   *// 
//*********************************************************************//
// Import the necessary packages 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.io.File;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
//--------------------------------------------------------------------
// The name of the abstract class is aReaderforXML 
public abstract class aReaderforXML 
{
	// Declare instance fields for class
	private Document chronicle; 
	private DocumentBuilderFactory docFactory; 
	private DocumentBuilder docConstruction;
	private File fileInsertion;
	//--------------------------------------------------------------------
	// A method for the Document package as well as providing
	// instantiate to the instance fields declared 
	public Document connectionMade(String identityFile)
	{
		// A try and catch statement is issued to provide error handling for
		// the connectToTheServer method 
		try 
		{
			docConstruction = docFactory.newDocumentBuilder();
			fileInsertion = new File(identityFile);
			docFactory = DocumentBuilderFactory.newInstance();
			chronicle = docConstruction.parse(fileInsertion);
			chronicle.getDocumentElement().normalize();
		} // End of try
		catch (Exception a)
		{
			a.printStackTrace();
		} // End of the catch statement 
		// the chronicle instance field is returned 
		return chronicle; 
	} // End of the public method 
	//--------------------------------------------------------------------
	// An abstract table which will be inherited to the ReadBooksXML and ReadAptsXML 
	// classes
	abstract void XMLtableViewer(String[][] theTable, String theColumn[], JPanel panelShow, JFrame showTheFrame);
} // End of class 
